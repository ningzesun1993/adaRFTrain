## Group Project Presentation

In this repo, we build a R package to train and predict decision tree and random forest, 

meanwhile build a function to use grid search and cross-validation to tune the hyper parameter of random forest

To install this package and read the file of vignettes, please follow this codes:

library(devtools)

install_github("ningzesun1993/adaRFTrain", build_vignettes = TRUE, force = TRUE)

browseVignettes("adaRFTrain")