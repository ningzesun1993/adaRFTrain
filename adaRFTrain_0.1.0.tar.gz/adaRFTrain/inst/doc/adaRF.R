## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----install------------------------------------------------------------------
# library(devtools)
# install_github("ningzesun1993/adaRFTrain", build_vignettes = TRUE, force = TRUE)
# browseVignettes("adaRFTrain")

## ----setup--------------------------------------------------------------------
devtools::load_all(".")
library(adaRFTrain)
library(caret)
library(superml)
library(MLmetrics)

## ----data---------------------------------------------------------------------
data(iris)
df = iris
df$Species = as.factor(LabelEncoder$new()$fit_transform(df$Species))
head(df)

## ----dt-----------------------------------------------------------------------
formula = "Species ~ ."
dt_r = dt_train(df, formula)
# head(dt_r)
confusionMatrix(dt_r$Species, dt_r$dt_p)

## ----dt_code------------------------------------------------------------------
# dt_train <- function(df, formula = NULL, df_test = NULL, p = 0.8,
#                      params_ = list(method = "recursive.partition",
#                                     split = c("deviance", "gini")),
#                      target = NULL) {
#   if (!is.null(target)){df[[target]] = as.factor(df[[target]])}
#   if (is.null(df_test)){
#     if (is.null(target)){target = names(df)[[length(names(df))]]}
#     index = caret::createDataPartition(y = df[[target]], p = p, list = FALSE)
#     df_train = df[index,]
#     df_test = df[-index,]
#   }else{
#     df_train = df
#   }
#   df_t = df_test[,!(names(df_test) %in% c(target))]
#   if (is.null(formula)){formula = paste0(target, " ~ .")}
#   dt = tree::tree(as.formula(formula), data = df_train, method = params_[["method"]],
#                   split = params_[["split"]])
#   dt_p = predict(dt, newdata = df_t, type = "class")
#   df_test = data.frame(cbind(df_test, dt_p))
#   return(df_test)
# }


## ----rf-----------------------------------------------------------------------
formula = "Species ~ ."
rf_r = rf_train(df, formula)
# head(rf_r)
confusionMatrix(rf_r$Species, rf_r$rf_p)

## ----rf_code------------------------------------------------------------------
# rf_train <- function(df, formula = NULL, df_test = NULL, p = 0.8,
#                      params_ = list(ntree = 500, sampsize = NULL, nodesize = NULL,
#                                     maxnodes = NULL, replace = TRUE, mtry = NULL,
#                                     strata = NULL), target = NULL) {
#   if (!is.null(target)){df[[target]] = as.factor(df[[target]])}
#   if (is.null(df_test)){
#     if (is.null(target)){target = names(df)[[length(names(df))]]}
#     index = caret::createDataPartition(y = df[[target]], p = p, list = FALSE)
#     df_train = df[index,]
#     df_test = df[-index,]
#     df_t = df_test
#   }else{
#     df_train = df
#   }
#   df_t = df_test[,!(names(df_test) %in% c(target))]
#   if (is.null(formula)){formula = paste0(target, " ~ .")}
#   if (is.null(params_[['sampsize']])){params_[['sampsize']] = nrow(df_train)}
#   if (is.null(params_[['mtry']])){params_[['mtry']] = floor(sqrt(ncol(df_train)))}
#   if (is.null(params_[['strata']])){params_[['strata']] = target}
#   rf = randomForest::randomForest(as.formula(formula), data = df_train, ntree = params_[['ntree']],
#                                   sampsize = params_[['sampsize']], nodesize = params_[['nodesize']],
#                                   maxnodes = params_[['maxnodes']], replace = params_[['replace']],
#                                   mtry = params_[['mtry']], strata = params_[['strata']])
#   rf_p = predict(rf, newdata = df_t, type = "class")
#   df_test = data.frame(cbind(df_test, rf_p))
#   return(df_test)
# }


## ----grid_search--------------------------------------------------------------
target = "Species"
params_range = list(n_estimators = seq(50, 200, 10))
params = grid_search_rf(df, params_range, target = target)
rf_grid = rf_train(df, target = target, params_ = params)
confusionMatrix(rf_r$Species, rf_r$rf_p)

## ----grid_search_code---------------------------------------------------------
# grid_search_rf <- function(df, params_range, target, n_fold = 3, scoring = c("accuracy", "auc"),
#                            params_ = list(ntree = 500, sampsize = NULL, nodesize = NULL,
#                                           maxnodes = NULL, replace = TRUE, mtry = NULL,
#                                           strata = NULL)) {
#   if (!is.null(target)){df[[target]] = as.factor(df[[target]])}
#   if (!is.null(df_test)){if (is.null(target)){target = names(df)[[length(names(df))]]}}
#   if (is.null(params_[['sampsize']])){params_[['sampsize']] = nrow(df_train)}
#   if (is.null(params_[['mtry']])){params_[['mtry']] = floor(sqrt(ncol(df_train)))}
#   if (is.null(params_[['strata']])){params_[['strata']] = target}
#   rf = superml::RFTrainer$new()
#   rf_grid = superml::GridSearchCV$new(trainer = rf, parameters = params_range,
#                          n_folds = n_fold, scoring = scoring)
#   rf_grid$fit(df, target)
#   result = rf_grid$best_iteration(metric = NULL)
#   for (i in names(params_range)){
#     params_[[i]] = result[[i]]
#   }
#   return(params_)
# }



